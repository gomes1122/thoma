alert("Hola mundo desde la consola!");

let propinaTotal = 0;

let cliente1 = prompt("¿Cuánto pagó el cliente 1?");
let propina1 = cliente1 * 0.10;
propinaTotal += propina1;

let cliente2 = prompt("¿Cuánto pagó el cliente 2?");
let propina2 = cliente2 * 0.10;
propinaTotal += propina2;

let cliente3 = prompt("¿Cuánto pagó el cliente 3?");
let propina3 = cliente3 * 0.10;
propinaTotal += propina3;

let cliente4 = prompt("¿Cuánto pagó el cliente 4?");
let propina4 = cliente4 * 0.10;
propinaTotal += propina4;

let cliente5 = prompt("¿Cuánto pagó el cliente 5?");
let propina5 = cliente5 * 0.10;
propinaTotal += propina5;

alert("La propina total que deben dejar los 5 clientes es: $" + propinaTotal);