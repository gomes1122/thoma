function login() {
  const user = document.getElementById('username').value;
  const pass = document.getElementById('password').value;

  const validUser = "thomas";
  const validPass = "1234";

  if (user === validUser && pass === validPass) {
    // Oculta el modal y el fondo negro
    document.getElementById('loginModal').style.display = 'none';
    document.getElementById('fondoNegro').style.display = 'none';

    // Muestra el contenido principal de la página
    document.getElementById('contenidoPagina').style.display = 'block';
  } else {
    alert("Usuario o contraseña incorrectos");
  }
}